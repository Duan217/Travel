# Apps From Scratch | Flutter Travel UI Starter Repo

Clone this repo and follow my YouTube video: [Flutter Travel UI Tutorial | Apps From Scratch](https://youtu.be/CSa6Ocyog4U)

[Complete Travel UI](https://github.com/MarcusNg/flutter_travel_ui)
